import time
import sys
import random
import string
import json
from ast import literal_eval

class Tardis:
    def __init__(self, desktop="Default Desktop", shell="Default Shell", destination="Unset", fuel=100, current_location="Nowhere"):
        self.random_multiplier = 1
        self.desktop = desktop
        self.shell = shell
        self.destination = destination
        self.fuel = fuel
        self.current_location = current_location
        self.circuits = {
            "Temporal": {"working": True, "health": 100},
            "Navigation": {"working": True, "health": 100},
            "Energy": {"working": True, "health": 100},
            "Chameleon": {"working": True, "health": 100},
            "Demat (Dematerialization)": {"working": True, "health": 100},
            "Artificial Reconfiguration System": {"working": True, "health": 100},
            "Fluid Links": {"working": True, "health": 100}
        }
        self.tardis_map = {
            "Console Room": {"connected_rooms": {}}
        }
        self.load_state()

    def save_state(self, filename="tardis_state.json"):
        state_data = {
            "desktop": self.desktop,
            "shell": self.shell,
            "destination": self.destination,
            "fuel": self.fuel,
            "current_location": self.current_location,
            "circuits": self.circuits,
            "tardis_map": {
                str(position): {
                    "room_name": value.get("room_name", "Unknown Room"),
                    "connected_rooms": value.get("connected_rooms", {})
                } for position, value in self.tardis_map.items()
            }
        }

        with open(filename, 'w') as file:
            json.dump(state_data, file)

        print(f"TARDIS state saved to {filename}.")

    def load_state(self, filename="tardis_state.json"):
        try:
            with open(filename, 'r') as file:
                content = file.read()
                if not content:
                    print(f"File {filename} is empty. Using default state.")
                    return

                state_data = json.loads(content)

            self.desktop = state_data.get("desktop", "Default Desktop")
            self.shell = state_data.get("shell", "Default Shell")
            self.destination = state_data.get("destination", "Unset")
            self.fuel = state_data.get("fuel", 100)
            self.current_location = state_data.get("current_location", "Nowhere")
            self.circuits = state_data.get("circuits", {})

            # Convert map positions back to tuples using eval
            self.tardis_map = {}
            for key, value in state_data.get("tardis_map", {}).items():
                try:
                    position = eval(key)
                    self.tardis_map[position] = value
                except (NameError, SyntaxError):
                    print(f"Error evaluating position: {key}. Skipping this entry.")
            print(f"TARDIS state loaded from {filename}.")
        except FileNotFoundError:
            print(f"No previous TARDIS state found. Starting with default state.")
        except json.decoder.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            print(f"Content of {filename}: {content}")
        except SyntaxError as e:
            print(f"Error in syntax: {e}")
            print(f"Content of {filename}: {content}")

    def add_custom_room(self, row, col, room_name):
        if self.circuits["Artificial Reconfiguration System"]["working"]:
            if room_name.lower() == "console room":
                return "Cannot replace the Console Room. Choose a different location."
            
            if 0 <= row < 10 and 0 <= col < 10:
                position = (row, col)
                if position not in self.tardis_map:
                    self.tardis_map[position] = {"connected_rooms": {}}
                    self.tardis_map[position]["room_name"] = room_name
                    self.save_state()
                    return f"Custom room '{room_name}' added at position {position}."
                else:
                    return "A room already exists at that position. Choose an empty slot."
            else:
                return "Invalid position. Choose a position within the 10x10 grid."
        else:
            return "Artificial Reconfiguration System is damaged. Cannot add custom rooms."

    def load_room_name(self):
        row = int(input("Enter the row(Top to Bottom) [1-10] for the room: "))
        col = int(input("Enter the column(Left to Right) [1-10] for the room: "))
        position = (row - 1, col - 1)

        if position in self.tardis_map:
            room_name = self.tardis_map[position].get("room_name", "Unknown Room")
            return f"The room at position {position} is: {room_name}"
        else:
            return "No room found at the specified position."

    def find_room(self):
        target_room_name = input("Enter the name of the room to find: ").lower()

        for position, room_info in self.tardis_map.items():
            if "room_name" in room_info and room_info["room_name"].lower() == target_room_name:
                return f"The room '{target_room_name.capitalize()}' is at position {position[0] + 1}, {position[1] + 1}."

        return f"No room found with the name '{target_room_name.capitalize()}'."

    def go_to_room(self):
        row = int(input("Enter the row(Top to Bottom) [1-10] for the room: "))
        col = int(input("Enter the column(Left to Right) [1-10] for the room: "))
        position = (row - 1, col - 1)

        if position in self.tardis_map:
            room_name = self.tardis_map[position].get("room_name", "Unknown Room")
            return f"Entering the room: {room_name}"
        else:
            return "No room found at the specified position."

    def display_tardis_map_options(self):
        print("\nTARDIS Map Options:")
        print("1. Back to Console Room")
        print("2. Load Room Name")
        print("3. Find Room")
        print("4. Add Room")
        print("5. Go to Room")

    def view_tardis_map(self):
        map_representation = ""
        for row in range(10):
            for col in range(10):
                position = (row, col)
                if position == (4, 4):  # Console Room location
                    map_representation += "C "
                elif position in self.tardis_map:
                    room_name = self.tardis_map[position].get("room_name", "Unknown Room")
                    map_representation += f"{room_name[0]} "
                else:
                    map_representation += ". "
            map_representation += "\n"

        print("\nTARDIS Map:")
        print(map_representation)

    
    def reset_tardis(self):
        self.desktop = "Default Desktop"
        self.shell = "Default Shell"
        self.destination = "Unset"
        self.fuel = 100
        self.current_location = "Nowhere"
        self.circuits = {
            "Temporal": {"working": True, "health": 100},
            "Navigation": {"working": True, "health": 100},
            "Energy": {"working": True, "health": 100},
            "Chameleon": {"working": True, "health": 100},
            "Demat (Dematerialization)": {"working": True, "health": 100},
            "Artificial Reconfiguration System": {"working": True, "health": 100},
            "Fluid Links": {"working": True, "health": 100}
        }
        self.tardis_map = {
            "Console Room": {"connected_rooms": {}}
        }
        self.save_state()
        print("TARDIS reset to default state. Exiting UI.")
        sys.exit()
    
    def damage_circuits(self):
        # Simulate damage to circuits during flight
        for circuit, details in self.circuits.items():
            # Probability of circuit damage during flight
            damage_probability = 0.25  # 25% chance of damage (adjust as needed)

            if random.random() < damage_probability:
                # Reduce circuit health by a random percentage
                damage_amount = random.randint(20, 45)  # Damage between 20% and 45% (adjust as needed)
                previous_health = details["health"]
                details["health"] = max(previous_health - damage_amount, 0)

                # Print a message when a circuit stops working
                if previous_health > 0 and details["health"] == 0:
                    details["working"] = False
                    print(f"{circuit} has stopped working.")

    def repair_circuit(self, circuit):
        if circuit in self.circuits:
            self.circuits[circuit]["working"] = True
            self.circuits[circuit]["health"] = 100
            return f"{circuit} has been repaired."
        else:
            return f"{circuit} is not a valid circuit name."

    def check_circuit_status(self, circuit):
        if circuit in self.circuits:
            return f"{circuit} Circuit: {'Working' if self.circuits[circuit]['working'] else 'Malfunction'} - Health: {self.circuits[circuit]['health']}%"
        else:
            return f"{circuit} is not a valid circuit name."

    def change_desktop(self, new_desktop):
        if self.circuits["Artificial Reconfiguration System"]["working"]:
            # Check if the provided desktop is a preset one or generate a new random desktop
            if new_desktop.lower() == "generate new":
                new_desktop = self.generate_random_desktop()
            elif new_desktop.title() not in self.get_preset_desktops():
                return "Invalid desktop name. Choose a preset one or use 'generate new.'"
        else:
            return "Artificial Reconfiguration System is damaged. Desktop change is not possible."

        self.desktop = new_desktop
        self.save_state()
        return f"Desktop changed to {new_desktop}"

    def generate_random_desktop(self):
        # Generate a random desktop name that sounds appropriate
        prefixes = ["Cosmic", "Quantum", "Infinite", "Galactic", "Celestial", "Nebula", "Stellar", "Walnut", "Spinning", "Coastal", "Ticking", "Cherry", "Aquatic", "Ancient", "Warped", "Steampunk", "Neon", "Helix", "Hourglass", "Vortex", "Soundwave", "Crimson", "Modern", "Fourth Dimensional"]
        suffix = "Desktop"

        random_name = f"{random.choice(prefixes)} {suffix}"
        return random_name

    def get_preset_desktops(self):
        # Define preset desktops
        return ["Default Desktop", "Victorian Desktop", "Classic Coral Desktop", "Coral Desktop", "Toyota Desktop V1", "Toyota Desktop V2", "Crystaline Desktop", "White Desktop"]

    def run_diagnostic_checks(self):
        result = "Running diagnostic checks...\n"

        for circuit, status in self.circuits.items():
            result += f"{circuit} Circuit: {'Working' if status else 'Malfunction'}\n"

        if all(self.circuits.values()):
            result += "All systems are functioning properly."
        else:
            result += "Some systems are malfunctioning. Please check the circuits."

        return result

    def change_exterior_shell(self, new_shell):
        self.shell = new_shell
        return f"Exterior shell changed to {new_shell}"

    def set_destination(self, new_destination):
        self.destination = new_destination
        self.random_multiplier = random.randint(8, 13) if "infinity" in new_destination.lower() or "gallifrey" in new_destination.lower() else random.randint(1, 7)
        return f"Destination set to {new_destination}"

    def calculate_actual_flight_time(self):
        # Calculate actual flight time based on the total length of destination
        total_length = len(self.destination)

        # Use the stored random multiplier
        multiplier = self.random_multiplier

        # Adjust the divisor based on the total length and multiplier
        divisor = 2  # Short distances take less time, long distances take more time

        # Calculate actual flight time with adjusted formula
        actual_flight_time = max((total_length * multiplier) // divisor, 5)  # Minimum 5 seconds for actual flight time

        # Separate calculation for the return trip
        return_multiplier = 2 if "gallifrey" in self.current_location.lower() else 1

        # Apply return trip multiplier
        actual_flight_time *= return_multiplier

        return actual_flight_time

    def calculate_flight_details(self):
        if self.destination == "Unset":
            return "Destination is not set. Cannot calculate flight details."

        # Adjust the calculation of fuel usage based on twice the length of the current location
        fuel_usage = len(self.current_location) * 2
        additional_time = random.randint(1,2)
        if additional_time == 1:
            estimated_flight_time = self.calculate_actual_flight_time() + 2
        else:
            estimated_flight_time = self.calculate_actual_flight_time() - 2

        return f"Estimated Fuel Usage: {fuel_usage} units, Estimated Flight Time: {estimated_flight_time} seconds"

    def travel(self):
        if self.destination == "Unset":
            return "Cannot initiate travel without a set destination."

        if self.fuel <= 0:
            return "Insufficient fuel. Please refuel before initiating travel."

        if self.destination.lower() == self.current_location.lower():
            return "You are already at the destination. No need to travel."

        flight_details = self.calculate_flight_details()
        if "Cannot calculate flight details" in flight_details:
            return flight_details

        actual_flight_time = self.calculate_actual_flight_time()

        # Progress bar
        print("Initiating travel:")
        for i in range(1, actual_flight_time + 1):
            sys.stdout.write("\r[{:<60}] {:.2f}%".format("=" * (i * 60 // actual_flight_time), i / actual_flight_time * 100))
            sys.stdout.flush()
            time.sleep(1)

        sys.stdout.write("\n")
        sys.stdout.flush()

        # Update current location after travel
        self.current_location = self.destination

        self.fuel -= len(self.destination) * 2  # Arbitrary fuel deduction based on destination length

        self.save_state()
        # Display actual flight time after travel
        return f"Travel to {self.destination} complete. {flight_details} Actual Flight Time: {actual_flight_time} seconds"

# Example usage with user input:
def main():
    my_tardis = Tardis()

    while True:
        print("\nCurrent TARDIS Configuration:")
        print(f"Desktop: {my_tardis.desktop}")
        print(f"Exterior Shell: {my_tardis.shell}")
        print(f"Destination: {my_tardis.destination}")
        print(f"Current Location: {my_tardis.current_location}")
        print(f"Fuel: {my_tardis.fuel} units")

        user_choice = input("\nChoose an action:\n1. Change Desktop\n2. Run Diagnostic Checks\n3. Change Exterior Shell\n4. Set Destination\n5. Calculate Flight Details\n6. Initiate Travel\n7. View TARDIS Map\n8. Exit\n9. Reset TARDIS\n")


        if user_choice == "1":
            print("Preset Desktops:")
            print(", ".join(my_tardis.get_preset_desktops()))
            print("Type 'generate new' to get a random desktop.")
            new_desktop = input("Enter the new desktop: ")
            result_desktop_change = my_tardis.change_desktop(new_desktop)
            print(result_desktop_change)
        elif user_choice == "2":
            diagnostic_result = my_tardis.run_diagnostic_checks()
            print(diagnostic_result)
        elif user_choice == "3":
            new_shell = input("Enter the new exterior shell: ")
            result_shell_change = my_tardis.change_exterior_shell(new_shell)
            print(result_shell_change)
        elif user_choice == "4":
            new_destination = input("Enter the new destination: ")
            result_destination_set = my_tardis.set_destination(new_destination)
            print(result_destination_set)
        elif user_choice == "5":
            flight_details = my_tardis.calculate_flight_details()
            print(flight_details)
        elif user_choice == "6":
            travel_result = my_tardis.travel()
            print(travel_result)
        elif user_choice == "7":
            my_tardis.view_tardis_map()
            my_tardis.display_tardis_map_options()
            while True:
                user_choice_map = input("Enter your choice (1-4): ")
                if user_choice_map == "1":
                    break  # Go back to the main UI
                elif user_choice_map == "2":
                    result_load_room_name = my_tardis.load_room_name()
                    print(result_load_room_name)
                elif user_choice_map == "3":
                    result_find_room = my_tardis.find_room()
                    print(result_find_room)
                elif user_choice_map == "4":
                    row = int(input("Enter the row(Top to Bottom) [1-10] for the new room: "))
                    col = int(input("Enter the column(Left to Right) [1-10] for the new room: "))
                    row = row - 1
                    col = col -1
                    room_name = input("Enter the name of the custom room: ")
                    result_add_room = my_tardis.add_custom_room(row, col, room_name)
                    print(result_add_room)
                elif user_choice_map == "5":
                    result_go_to_room = my_tardis.go_to_room()
                    print(result_go_to_room)
                else:
                    print("Invalid choice. Please enter a number between 1 and 5.")
        elif user_choice == "8":
            print("Exiting TARDIS UI. Goodbye!")
            break
        elif user_choice == "9":
            my_tardis.reset_tardis()
        else:
            print("Invalid choice. Please enter a number between 1 and 9.")

if __name__ == "__main__":
    main()